package com.fmsupdater;

import android.os.AsyncTask;
import android.util.Log;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

public class FetchXMLData extends AsyncTask<Void, Void, Void> {
    private String multiUrls = "";
    private String url = "";

    @Override
    protected Void doInBackground(Void... voids) {
        try {
            URL url = new URL("https://fuadzyoud.github.io/IPTV/servers.xml");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.connect();

            InputStream inputStream = connection.getInputStream();
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputStream);
            doc.getDocumentElement().normalize();

            NodeList serverList = doc.getElementsByTagName("server");

            if (serverList.getLength() > 0) {
                Node serverNode = serverList.item(0);
                if (serverNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element serverElement = (Element) serverNode;

                    NodeList multiUrlsList = serverElement.getElementsByTagName("multi_urls");
                    if (multiUrlsList.getLength() > 0) {
                        multiUrls = multiUrlsList.item(0).getTextContent().trim();
                    }

                    NodeList urlList = serverElement.getElementsByTagName("url");
                    if (urlList.getLength() > 0) {
                        url = urlList.item(0).getTextContent().trim();
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
        Log.d("FetchXMLData", "Multi URLs: " + multiUrls);
        Log.d("FetchXMLData", "URL: " + url);
    }

    public String getMultiUrls() {
        return multiUrls;
    }

    public String getUrl() {
        return url;
    }
}
}
